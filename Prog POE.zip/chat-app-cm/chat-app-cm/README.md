# QuickChat - Chat Application

A simple command-line chat application built with Java.

## Features

- User Registration with validation
- User Login
- Send Messages with validation
- Message storage and tracking
- View message history

## How to Run the Application

### On Windows:
```bash
gradlew.bat run
```

### On Mac/Linux:
```bash
./gradlew run
```

## How to Run Tests

### Run all tests:
```bash
gradlew.bat test
```

### Run specific test class:
```bash
gradlew.bat test --tests MessageTest
gradlew.bat test --tests AuthServiceTest
```

## User Guide

### Registration
1. Select option 1 (Register)
2. Enter a username (max 5 characters, letters/numbers/underscore)
3. Enter a password (min 8 characters, must contain uppercase, lowercase, digit, and special character)
4. Enter a phone number (international format, e.g., +27123456789)

### Login
1. Select option 2 (Login)
2. Enter your username
3. Enter your password

### Sending Messages
After login, you'll see the QuickChat menu:
1. **Send messages** - Send new messages
2. **Show recently sent messages** - View all sent messages
3. **Quit** - Logout and return to main menu

When sending messages:
- Specify how many messages you want to send
- For each message, provide:
  - Message ID (max 10 characters)
  - Recipient cell number (max 10 characters)
  - Message content (max 250 characters)
- Choose to Send, Store, or Disregard each message

## Project Structure

```
app/src/main/java/com/chatapp/
├── Main.java           - Main application entry point
├── AuthService.java    - Handles user registration and login
├── User.java          - User data model
└── Message.java       - Message handling and validation

app/src/test/java/com/chatapp/
├── MessageTest.java      - Unit tests for Message class
└── AuthServiceTest.java  - Unit tests for AuthService class
```

## Validation Rules

### Username
- Max 5 characters
- Only letters, numbers, and underscore allowed

### Password
- Min 8 characters
- Must contain at least one uppercase letter
- Must contain at least one lowercase letter
- Must contain at least one digit
- Must contain at least one special character (@$!%*?&)

### Phone Number
- Max 10 characters
- Must start with a digit or +
- International format recommended

### Message ID
- Max 10 characters

### Message Content
- Max 250 characters

