# Unit Tests Summary

This document explains all the unit tests created for the QuickChat application.

## MessageTest.java

### Test Data from Task 1

**Message 1:**
- Recipient: +27718693002
- Content: "Hi Mike, can you join us for dinner tonight."
- Action: Send

**Message 2:**
- Recipient: 08575975889
- Content: "Hi Kengan, did you receive the payment?"
- Action: Discard

### Tests Included:

1. **testMessageHashIsCorrect()**
   - Tests that the message hash is generated correctly
   - Verifies hash starts with "MSG-"

2. **testMessageIDIsCreated()**
   - Tests that message ID is properly assigned
   - Expected output: "Message ID generated: <Message ID>"

3. **testCheckMessageIDSuccess()**
   - Tests valid message ID (10 characters or less)
   - Should return true

4. **testCheckMessageIDFailure()**
   - Tests invalid message ID (more than 10 characters)
   - Should return false

5. **testCheckRecipientCellSuccess()**
   - Tests valid cell number format
   - Expected output: "Cell phone number successfully captured."

6. **testCheckRecipientCellFailure()**
   - Tests invalid cell number format
   - Expected output: "Cell phone number is incorrectly formatted or does not contain an international code."

7. **testMessageLengthSuccess()**
   - Tests message with 250 characters or less
   - Expected output: "Message ready to send."

8. **testMessageLengthFailure()**
   - Tests message exceeding 250 characters
   - Expected output: "Message exceeds 250 characters by X, please reduce size."

9. **testMessage1()**
   - Tests complete message creation with data from Message 1
   - Validates all fields

10. **testMessage2()**
    - Tests complete message creation with data from Message 2
    - Validates all fields

11. **testCreateMessageHash()**
    - Tests that hash is consistently generated
    - Same message should produce same hash

12. **testGetMessageID()**
    - Tests the getMessageID() getter method

13. **testGetRecipientCell()**
    - Tests the getRecipientCell() getter method

14. **testGetMessageContent()**
    - Tests the getMessageContent() getter method

15. **testReturnTotalMessages()**
    - Tests that total message count is returned correctly
    - Count should be >= 0

16. **testPrintMessage()**
    - Tests that message list is formatted correctly
    - Should return formatted string

17. **testStoreMessage()**
    - Tests JSON formatting of messages
    - Should return valid JSON array format

## AuthServiceTest.java

### Tests Included:

1. **testRegisterSuccess()**
   - Tests successful user registration
   - All validation rules pass

2. **testRegisterInvalidUsername()**
   - Tests registration with username longer than 5 characters
   - Should fail validation

3. **testRegisterWeakPassword()**
   - Tests registration with weak password
   - Should fail validation

4. **testRegisterInvalidPhone()**
   - Tests registration with invalid phone number
   - Should fail validation

5. **testRegisterDuplicateUsername()**
   - Tests registration with already existing username
   - Should fail

6. **testLoginSuccess()**
   - Tests successful login with correct credentials
   - Should return true

7. **testLoginWrongPassword()**
   - Tests login with incorrect password
   - Should fail

8. **testLoginNonExistentUser()**
   - Tests login with username that doesn't exist
   - Should fail

9. **testUsernameValidation()**
   - Tests various username formats
   - Valid: max 5 characters
   - Invalid: more than 5 characters

10. **testPasswordValidation()**
    - Tests password requirements
    - Must have: uppercase, lowercase, digit, special character
    - Min 8 characters

11. **testPhoneValidation()**
    - Tests phone number formats
    - Valid: international format with + or digits
    - Invalid: too short or contains letters

## How to Run Specific Tests

Run all tests:
```bash
gradlew.bat test
```

Run only Message tests:
```bash
gradlew.bat test --tests MessageTest
```

Run only Auth tests:
```bash
gradlew.bat test --tests AuthServiceTest
```

Run a specific test method:
```bash
gradlew.bat test --tests MessageTest.testMessageHashIsCorrect
```

## Expected Test Results

All tests should pass if:
- Message validation works correctly
- User authentication works correctly
- Message storage works correctly
- JSON formatting is valid

## Test Coverage

These tests cover:
- ✅ Message ID validation
- ✅ Recipient cell validation
- ✅ Message length validation (250 char limit)
- ✅ Message hash generation
- ✅ Username validation (5 char limit)
- ✅ Password strength validation
- ✅ Phone number validation
- ✅ User registration
- ✅ User login
- ✅ Message storage
- ✅ Total message count

