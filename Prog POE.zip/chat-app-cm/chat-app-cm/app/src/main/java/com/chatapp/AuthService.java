/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chatapp;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 *
 * @author chantelm
 */
public class AuthService {
    private Map<String, User> users = new HashMap<>();
    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[A-Za-z0-9_]{1,5}$");
    private static final Pattern PASSWORD_PATTERN = Pattern
            .compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\+?[1-9]\\d{9,14}$");

    public boolean register(String username, String password, String phone) {
        if (!USERNAME_PATTERN.matcher(username).matches()) {
            System.out.println(" Invalid username. Use up to 5 characters (letters, numbers, underscore).");
            return false;
        }

        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            System.out.println("Weak password. Must be 8+ chars with uppercase, lowercase, digit, special char.");
            return false;
        }

        if (!PHONE_PATTERN.matcher(phone).matches()) {
            System.out.println("Invalid phone number. Example: +27123456789");
            return false;
        }

        if (users.containsKey(username)) {
            System.out.println("Username already exists.");
            return false;
        }

        users.put(username, new User(username, password, phone));
        return true;
    }

    public boolean login(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return true;
        }
        System.out.println("Invalid username or password.");
        return false;
    }

}
