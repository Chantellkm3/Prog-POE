package com.chatapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Message class that handles message creation, validation, and storage
 */
public class Message {
    private String messageID;
    private String sender;
    private String recipientCell;
    private String messageContent;
    private String messageHash;
    private MessageStatus status;

    private static final List<Message> allMessages = new ArrayList<>();
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();
    private static final List<String> messageHashes = new ArrayList<>();
    private static final List<String> messageIds = new ArrayList<>();
    private static int totalMessagesSent = 0;

    public Message(String messageID, String recipientCell, String messageContent) {
        this(messageID, null, recipientCell, messageContent);
    }

    public Message(String messageID, String sender, String recipientCell, String messageContent) {
        this.messageID = messageID;
        this.sender = sender == null || sender.isBlank() ? "Unknown" : sender;
        this.recipientCell = recipientCell;
        this.messageContent = messageContent;
        this.messageHash = createMessageHash();
        this.status = MessageStatus.NEW;
    }

    /**
     * This method ensures that the message ID is not more than ten characters
     * 
     * @return true if message ID is valid (10 characters or less), false otherwise
     */
    public boolean checkMessageID() {
        if (messageID == null || messageID.length() > 10) {
            System.out.println("Error: Message ID must not be more than 10 characters.");
            return false;
        }
        return true;
    }

    /**
     * This method ensures that the recipient cell number is no more than ten
     * characters long
     * and starts with a valid format
     * 
     * @return 1 if valid, 0 if invalid
     */
    public int checkRecipientCell() {
        if (recipientCell == null || recipientCell.length() > 10) {
            System.out.println("Error: Recipient cell number must not be more than 10 characters.");
            return 0;
        }

        // Check if it starts with a digit or +
        if (!recipientCell.matches("^[+0-9].*")) {
            System.out.println("Error: Recipient cell number must start with a digit or +.");
            return 0;
        }

        return 1;
    }

    /**
     * This method checks that the message is not more than 250 characters
     * 
     * @return true if message is valid length, false otherwise
     */
    public boolean checkMessageLength() {
        if (messageContent == null) {
            System.out.println("Error: Message content cannot be null.");
            return false;
        }

        if (messageContent.length() > 250) {
            int excess = messageContent.length() - 250;
            System.out.println("Message exceeds 250 characters by " + excess + ", please reduce size.");
            return false;
        }

        System.out.println("Message ready to send.");
        return true;
    }

    /**
     * This method creates and returns the Message Hash
     * 
     * @return the generated message hash
     */
    public String createMessageHash() {
        // Create a hash from messageID and recipient cell
        int hash = (messageID + recipientCell + messageContent).hashCode();
        messageHash = "MSG-" + Math.abs(hash);
        return messageHash;
    }

    private void recordMessage(MessageStatus statusToUse) {
        this.status = statusToUse;

        if (!messageIds.contains(messageID)) {
            messageIds.add(messageID);
        }
        if (!messageHashes.contains(messageHash)) {
            messageHashes.add(messageHash);
        }

        switch (statusToUse) {
            case SENT:
                sentMessages.add(this);
                totalMessagesSent++;
                break;
            case STORED:
                storedMessages.add(this);
                break;
            case DISREGARDED:
                disregardedMessages.add(this);
                break;
            default:
                break;
        }

        allMessages.add(this);
    }

    /**
     * This method should allow the user to choose if they want to send, store, or
     * disregard the message
     *
     * @return status message indicating what action was taken
     */
    public String sentMessage(Scanner scanner) {
        System.out.println("\n--- Message Options ---");
        System.out.println("Message ID: " + messageID);
        System.out.println("Recipient: " + recipientCell);
        System.out.println("Content: " + messageContent);
        System.out.println("\nWhat would you like to do?");
        System.out.println("1. Send");
        System.out.println("2. Store (save for later)");
        System.out.println("3. Disregard");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        if (choice == 1) {
            recordMessage(MessageStatus.SENT);
            return "Message sent successfully! Hash: " + messageHash;
        } else if (choice == 2) {
            recordMessage(MessageStatus.STORED);
            return "Message stored for later.";
        } else if (choice == 3) {
            recordMessage(MessageStatus.DISREGARDED);
            return "Message discarded.";
        } else {
            return "Invalid option. Message discarded.";
        }
    }

    /**
     * This method returns a list of all the messages sent while the program is
     * running
     * 
     * @return formatted string containing all sent messages
     */
    public static String printMessage() {
        if (allMessages.isEmpty()) {
            return "No messages to display.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\n========== All Messages ==========\n");
        for (int i = 0; i < allMessages.size(); i++) {
            Message msg = allMessages.get(i);
            sb.append("\nMessage #").append(i + 1).append(":\n");
            sb.append("  Status: ").append(msg.status).append("\n");
            sb.append("  ID: ").append(msg.messageID).append("\n");
            sb.append("  From: ").append(msg.sender).append("\n");
            sb.append("  To: ").append(msg.recipientCell).append("\n");
            sb.append("  Content: ").append(msg.messageContent).append("\n");
            sb.append("  Hash: ").append(msg.messageHash).append("\n");
        }
        sb.append("==================================\n");
        return sb.toString();
    }

    /**
     * This method returns the total number of messages sent
     *
     * @return the total count of messages sent
     */
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    /**
     * Store the messages in JSON format
     * This method converts all messages to JSON format and returns the JSON string
     * 
     * @return JSON string representation of all messages
     */
    public static String storeMessage() {
        if (storedMessages.isEmpty()) {
            return "[]";
        }

        StringBuilder json = new StringBuilder();
        json.append("[\n");

        for (int i = 0; i < storedMessages.size(); i++) {
            Message msg = storedMessages.get(i);
            json.append("  {\n");
            json.append("    \"messageID\": \"").append(msg.messageID).append("\",\n");
            json.append("    \"sender\": \"").append(msg.sender).append("\",\n");
            json.append("    \"recipientCell\": \"").append(msg.recipientCell).append("\",\n");
            json.append("    \"messageContent\": \"").append(msg.messageContent).append("\",\n");
            json.append("    \"messageHash\": \"").append(msg.messageHash).append("\"\n");
            json.append("  }");

            if (i < storedMessages.size() - 1) {
                json.append(",");
            }
            json.append("\n");
        }

        json.append("]");
        return json.toString();
    }

    /**
     * Load stored messages from a JSON string (format produced by storeMessage).
     */
    public static void loadStoredMessagesFromJson(String json) {
        if (json == null || json.isBlank()) {
            return;
        }

        Pattern pattern = Pattern.compile("\\{\\s*\"messageID\": \"(.*?)\",\\s*\"sender\": \"(.*?)\",\\s*\"recipientCell\": \"(.*?)\",\\s*\"messageContent\": \"(.*?)\",\\s*\"messageHash\": \"(.*?)\"\\s*}",
                Pattern.DOTALL);
        Matcher matcher = pattern.matcher(json);

        while (matcher.find()) {
            String id = matcher.group(1);
            String senderFromJson = matcher.group(2);
            String recipient = matcher.group(3);
            String content = matcher.group(4);

            Message msg = new Message(id, senderFromJson, recipient, content);
            msg.recordMessage(MessageStatus.STORED);
        }
    }

    public static Message addMessageWithFlag(String messageID, String sender, String recipient, String content,
            MessageStatus status) {
        Message msg = new Message(messageID, sender, recipient, content);
        msg.recordMessage(status);
        return msg;
    }

    public static List<Message> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }

    public static List<Message> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }

    public static List<Message> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }

    public static List<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public static List<String> getMessageIds() {
        return new ArrayList<>(messageIds);
    }

    public static String displaySendersAndRecipients() {
        if (sentMessages.isEmpty()) {
            return "No sent messages yet.";
        }

        StringBuilder sb = new StringBuilder();
        for (Message msg : sentMessages) {
            sb.append(msg.sender).append(" -> ").append(msg.recipientCell).append("\n");
        }
        return sb.toString().trim();
    }

    public static String findLongestMessageContent() {
        List<Message> combined = new ArrayList<>();
        combined.addAll(sentMessages);
        combined.addAll(storedMessages);
        combined.addAll(disregardedMessages);

        if (combined.isEmpty()) {
            return "No messages available.";
        }

        Message longest = combined.get(0);
        for (Message msg : combined) {
            if (msg.messageContent.length() > longest.messageContent.length()) {
                longest = msg;
            }
        }
        return longest.messageContent;
    }

    public static Message findByMessageId(String id) {
        for (Message msg : allMessages) {
            if (msg.messageID.equals(id)) {
                return msg;
            }
        }
        return null;
    }

    public static List<Message> findByRecipient(String recipient) {
        List<Message> matches = new ArrayList<>();
        for (Message msg : sentMessages) {
            if (msg.recipientCell.equals(recipient)) {
                matches.add(msg);
            }
        }
        for (Message msg : storedMessages) {
            if (msg.recipientCell.equals(recipient)) {
                matches.add(msg);
            }
        }
        return matches;
    }

    public static String deleteByMessageHash(String hash) {
        Message toDelete = null;
        for (Message msg : new ArrayList<>(allMessages)) {
            if (msg.messageHash.equals(hash)) {
                toDelete = msg;
                break;
            }
        }

        if (toDelete == null) {
            return "Message not found.";
        }

        allMessages.remove(toDelete);
        sentMessages.remove(toDelete);
        storedMessages.remove(toDelete);
        disregardedMessages.remove(toDelete);
        messageHashes.remove(hash);
        messageIds.remove(toDelete.messageID);
        if (toDelete.status == MessageStatus.SENT && totalMessagesSent > 0) {
            totalMessagesSent--;
        }

        return "Message \"" + toDelete.messageContent + "\" successfully deleted.";
    }

    public static String displaySentReport() {
        if (sentMessages.isEmpty()) {
            return "No sent messages.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("\n===== Sent Messages Report =====\n");
        for (Message msg : sentMessages) {
            sb.append("Hash: ").append(msg.messageHash).append("\n");
            sb.append("Recipient: ").append(msg.recipientCell).append("\n");
            sb.append("Sender: ").append(msg.sender).append("\n");
            sb.append("Message: ").append(msg.messageContent).append("\n");
            sb.append("--------------------------------\n");
        }
        return sb.toString();
    }

    public static void resetAll() {
        allMessages.clear();
        sentMessages.clear();
        storedMessages.clear();
        disregardedMessages.clear();
        messageHashes.clear();
        messageIds.clear();
        totalMessagesSent = 0;
    }

    // Getters
    public String getMessageID() {
        return messageID;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipientCell() {
        return recipientCell;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public MessageStatus getStatus() {
        return status;
    }

    public enum MessageStatus {
        NEW, SENT, STORED, DISREGARDED
    }
}
