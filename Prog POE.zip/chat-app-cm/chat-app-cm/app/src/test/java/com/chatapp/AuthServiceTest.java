package com.chatapp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the AuthService class
 */
public class AuthServiceTest {

    private AuthService authService;

    @BeforeEach
    public void setUp() {
        authService = new AuthService();
    }

    /**
     * Test successful user registration
     */
    @Test
    public void testRegisterSuccess() {
        boolean result = authService.register("user1", "Password1!", "+27123456789");
        assertTrue(result);
        System.out.println("Registration successful!");
    }

    /**
     * Test registration with invalid username (too long)
     */
    @Test
    public void testRegisterInvalidUsername() {
        boolean result = authService.register("toolongusername", "Password1!", "+27123456789");
        assertFalse(result);
        System.out.println("Invalid username detected");
    }

    /**
     * Test registration with weak password
     */
    @Test
    public void testRegisterWeakPassword() {
        boolean result = authService.register("user2", "weak", "+27123456789");
        assertFalse(result);
        System.out.println("Weak password detected");
    }

    /**
     * Test registration with invalid phone number
     */
    @Test
    public void testRegisterInvalidPhone() {
        boolean result = authService.register("user3", "Password1!", "123");
        assertFalse(result);
        System.out.println("Invalid phone number detected");
    }

    /**
     * Test registration with duplicate username
     */
    @Test
    public void testRegisterDuplicateUsername() {
        authService.register("user4", "Password1!", "+27123456789");
        boolean result = authService.register("user4", "Password2!", "+27987654321");
        assertFalse(result);
        System.out.println("Duplicate username detected");
    }

    /**
     * Test successful login
     */
    @Test
    public void testLoginSuccess() {
        authService.register("user5", "Password1!", "+27123456789");
        boolean result = authService.login("user5", "Password1!");
        assertTrue(result);
        System.out.println("Login successful!");
    }

    /**
     * Test login with wrong password
     */
    @Test
    public void testLoginWrongPassword() {
        authService.register("user6", "Password1!", "+27123456789");
        boolean result = authService.login("user6", "WrongPass1!");
        assertFalse(result);
        System.out.println("Invalid username or password");
    }

    /**
     * Test login with non-existent user
     */
    @Test
    public void testLoginNonExistentUser() {
        boolean result = authService.login("ghost", "Password1!");
        assertFalse(result);
        System.out.println("Invalid username or password");
    }

    /**
     * Test username validation - must be 5 characters or less
     */
    @Test
    public void testUsernameValidation() {
        assertTrue(authService.register("abc", "Password1!", "+27123456789"));
        assertTrue(authService.register("ab_12", "Password2!", "+27123456788"));
        assertFalse(authService.register("toolong", "Password3!", "+27123456787"));
    }

    /**
     * Test password validation - must contain uppercase, lowercase, digit, special
     * char
     */
    @Test
    public void testPasswordValidation() {
        assertFalse(authService.register("test1", "password", "+27123456789"));
        assertFalse(authService.register("test2", "PASSWORD1!", "+27123456788"));
        assertFalse(authService.register("test3", "Password", "+27123456787"));
        assertTrue(authService.register("test4", "Valid123!", "+27123456786"));
    }

    /**
     * Test phone number validation - must match international format
     */
    @Test
    public void testPhoneValidation() {
        assertTrue(authService.register("ph1", "Password1!", "+27123456789"));
        assertTrue(authService.register("ph2", "Password2!", "1234567890"));
        assertFalse(authService.register("ph3", "Password3!", "+1"));
        assertFalse(authService.register("ph4", "Password4!", "abc123"));
    }
}
