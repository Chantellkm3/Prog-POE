package com.chatapp;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MessageTest {

    @BeforeEach
    public void resetMessages() {
        Message.resetAll();
    }

    private void seedTestData() {
        Message.addMessageWithFlag("Test Message 1", "Developer", "+27834557896", "Did you get the cake?",
                Message.MessageStatus.SENT);
        Message.addMessageWithFlag("Test Message 2", "Developer", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.",
                Message.MessageStatus.STORED);
        Message.addMessageWithFlag("Test Message 3", "Developer", "+27834484567", "Yohoooo, I am at your gate.",
                Message.MessageStatus.DISREGARDED);
        Message.addMessageWithFlag("08388884567", "Developer", "08388884567", "It is dinner time !",
                Message.MessageStatus.SENT);
        Message.addMessageWithFlag("Test Message 5", "Developer", "+27838884567", "Ok, I am leaving without you.",
                Message.MessageStatus.STORED);
    }

    @Test
    public void sentMessagesArrayCorrectlyPopulated() {
        seedTestData();
        List<Message> sent = Message.getSentMessages();

        assertEquals(2, sent.size());
        assertTrue(sent.stream().anyMatch(m -> m.getMessageContent().contains("cake")));
        assertTrue(sent.stream().anyMatch(m -> m.getMessageContent().contains("dinner time")));
    }

    @Test
    public void displaysLongestMessage() {
        seedTestData();
        String longest = Message.findLongestMessageContent();

        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    @Test
    public void searchForMessageIdShowsRecipientAndMessage() {
        seedTestData();
        Message found = Message.findByMessageId("08388884567");

        assertNotNull(found);
        assertEquals("It is dinner time !", found.getMessageContent());
        assertEquals("08388884567", found.getRecipientCell());
    }

    @Test
    public void searchMessagesByRecipientIncludesSentAndStored() {
        seedTestData();
        List<Message> matches = Message.findByRecipient("+27838884567");

        assertEquals(2, matches.size());
        assertTrue(matches.stream().anyMatch(m -> m.getMessageContent().startsWith("Where are you")));
        assertTrue(matches.stream().anyMatch(m -> m.getMessageContent().startsWith("Ok, I am leaving")));
    }

    @Test
    public void deleteMessageUsingHashRemovesFromCollections() {
        seedTestData();
        Message stored = Message.getStoredMessages().stream()
                .filter(m -> m.getMessageContent().startsWith("Where are you"))
                .findFirst()
                .orElseThrow();

        String response = Message.deleteByMessageHash(stored.getMessageHash());

        assertTrue(response.contains("successfully deleted"));
        assertFalse(Message.getStoredMessages().stream()
                .anyMatch(m -> m.getMessageHash().equals(stored.getMessageHash())));
        assertFalse(Message.getMessageHashes().contains(stored.getMessageHash()));
    }

    @Test
    public void displayReportListsSentMessages() {
        seedTestData();
        String report = Message.displaySentReport();

        assertTrue(report.contains("Hash:"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time !"));
        assertTrue(report.contains("Recipient: +27834557896"));
    }

    @Test
    public void validationChecksRemainIntact() {
        Message tooLong = new Message("MESSAGE-ID-TOO-LONG", "sender", "+123", "Test");
        assertFalse(tooLong.checkMessageID());

        Message badRecipient = new Message("MSG123", "sender", "abc", "Test");
        assertEquals(0, badRecipient.checkRecipientCell());

        String longContent = "x".repeat(251);
        Message longMsg = new Message("MSG124", "sender", "+27834567890", longContent);
        assertFalse(longMsg.checkMessageLength());
    }
}
